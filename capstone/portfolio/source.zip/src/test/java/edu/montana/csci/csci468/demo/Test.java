package edu.montana.csci.csci468.demo;

public class Test {
    String s = "ss" + "aa";
}
